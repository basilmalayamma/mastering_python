from distutils.core import setup 

setup(
        name = 'md_basi',
        version='1.1',
        py_modules=['m_basi'],
        author = 'basi',
        author_email='basil.ap@ignitarium.com'
        )
