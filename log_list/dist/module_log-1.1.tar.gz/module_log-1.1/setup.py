from distutils.core import setup 

setup(
        name = 'module_log',
        version='1.1',
        py_modules=['m_log'],
        author = 'basi',
        author_email='basil.ap@ignitarium.com'
        )
